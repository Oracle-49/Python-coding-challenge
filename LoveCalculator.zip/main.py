print("The Love Calculator is calculating your score...")
name1 = input("What is your name?: ")
name2 = input("What is their name?: ") 
combined_names = name1 + name2
lower_case = combined_names.lower()
t = lower_case.count("t")
r = lower_case.count("r")
u = lower_case.count("u")
e = lower_case.count("e")
first_digit = t + r + u + e
l = lower_case.count("l")
o = lower_case.count("o")
v = lower_case.count("v")
e = lower_case.count("e")
second_digit = l + o + v + e
score = str(first_digit) + str(second_digit)
score_no = int(score)

if score_no < 10 or score_no > 90:
  print(f"Your score is {score_no}, you go together like coke and mentos.")
elif score_no >= 40 and score_no <= 50:
  print(f"Your score is {score_no}, you are alright together.")
else:
  print(f"Your score is {score_no}")