import random

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

options = [rock, paper, scissors]
names = ["rock", "paper", "scissors"]

print("WELCOME TO ROCK, PAPER, SCISSORS")

while True:
    user_input = int(input("Please enter '0' for rock, '1' for paper and '2' for scissors: "))
    if user_input >= 0 and user_input <= 2:
        print(f"You chose {names[user_input]} {options[user_input]}")
        computer_choice = random.randint(0,2)
        print(f"The computer chose {names[computer_choice]} {options[computer_choice]}")
        if user_input == computer_choice:
            print("It's a tie")
        elif (user_input == 0 and computer_choice == 2) or \
             (user_input == 1 and computer_choice == 0) or \
             (user_input == 2 and computer_choice == 1):
            print("You won!")
        else:
            print("Computer won")
    else:
        print("Please enter a valid number (0, 1, or 2)")

