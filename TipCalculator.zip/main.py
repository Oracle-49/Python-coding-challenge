bill = float(input( "What is the total bill?: $" ))
tip = int(input( "What is the tip percentage?: " ))
people = int(input( "How many people are splitting the bill?: " ))
percentage_tip = tip/100
total_tip = bill * percentage_tip
total_bill = round(total_tip + bill, 2)
split_bill = round(total_bill/people, 2)
print(f"Your total bill including tip is ${total_bill} each person is to pay ${split_bill}")