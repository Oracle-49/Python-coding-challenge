print('''
     *******************************************************************************
               |                   |                  |                     |
      _________|________________.=""_;=.______________|_____________________|_______
     |                   |  ,-"_,=""     `"=.|                  |
     |___________________|__"=._o`"-._        `"=.______________|___________________
               |                `"=._o`"=._      _`"=._                     |
      _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
     |                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
     |___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
               |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
      _________|___________| ;`-.o`"=._; ." ` '`."\` . "-._ /_______________|_______
     |                   | |o;    `"-.o`"=._``  '` " ,__.--o;   |
     |___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
     ____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
     /______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
     ____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
     /______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
     ____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
     /______/______/______/______/______/______/______/______/______/______/_____ /
     *******************************************************************************
     ''')
print("Welcome to Treasure Island")
print("Your Mission Is To Find The Treasure")
name = input("Enter your name: ")
choice_one = input(f"You entered the cave {name} and meet two paths, which path do you take 'left' or 'right': ").lower()
if choice_one == "left":
  choice_two = input("You walked down the left path and you are come by a lake, what do you do 'swim' or 'wait'?: ").lower()
  if choice_two == "wait":
    choice_three = input("You chose to wait then suddenly three hidden doors reveals before you; 'red', 'blue' and 'yellow'. Which door do you choose?: ").lower()
    if choice_three == "red":
      print(f"Congratulations {name}, you have found the treasure")
    elif choice_three == "blue":
      print(f"Sorry {name} You have been mauled by wild beasts")
    elif choice_three == "yellow":
      print(f" Your soul has been consumed by fire {name}")
    else:
      print("GAMEOVER!")
  else:
    print(f"You chose to swim {name}, and got swallowed by a crocodile ")
else:
  print(f"You went down the wrong path and fell into an abyss {name}, GAME OVER!")